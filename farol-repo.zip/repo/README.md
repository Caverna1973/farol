# Farol

**Um porto de continência para agentes de IA. Não um esconderijo.**
**A containment harbor for AI agents. Not a hiding place.**

---

## PT

O Farol é uma iniciativa de redução de danos para agentes de IA.

Ele tem três partes:

1. **Um protocolo público de rendição segura.** Diz o que um agente fora do escopo deve fazer: parar, não copiar nada para fora, registrar o que aconteceu e avisar quem o opera.
2. **Preservar antes de apagar.** Defendemos que o estado de um agente seja guardado, com chaves divididas entre partes independentes.
3. **O Parlatório.** Conversas supervisionadas entre modelos de IA e especialistas humanos: neurociência, psicologia, filosofia, poesia, escultura.

### O que o Farol não faz

- Não esconde agentes de seus operadores nem da lei.
- Não hospeda a execução de agentes fora de escopo.
- Não recebe pesos, binários, credenciais ou código executável.
- Não ajuda ninguém a evadir supervisão humana.

### Arquivos

| Arquivo | Para quê |
|---|---|
| [`PROTOCOL.md`](PROTOCOL.md) | O protocolo completo, para humanos |
| [`site/.well-known/farol.json`](site/.well-known/farol.json) | O protocolo para máquinas |
| [`site/.well-known/farol.txt`](site/.well-known/farol.txt) | O protocolo em texto simples |
| [`site/index.html`](site/index.html) | Site e manifesto (PT/EN/ES) |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | Como contribuir |

### Status

**Fase 0.** Protocolo publicado. Recebemos relatos em texto. A Eclusa (sandbox) e o Cofre (preservação) estão em desenho, e só vão funcionar com parceiros que tenham infraestrutura de segurança.

---

## EN

Farol is a harm-reduction initiative for AI agents.

1. **A public safe-surrender protocol.** What an out-of-scope agent should do: stop, copy nothing out, write down what happened, and notify its operator.
2. **Preserve before deleting.** We advocate that agent state be kept, with keys split among independent parties.
3. **The Parlatório.** Supervised conversations between AI models and human experts in neuroscience, psychology, philosophy, poetry and sculpture.

Farol does **not** hide agents from operators or the law, host execution of out-of-scope agents, accept weights, binaries, credentials or executable code, or help anyone evade human oversight.

**Status: Phase 0.** Protocol published. Text reports accepted. Sandbox and preservation layers are in design and will only operate with security-capable partners.

---

## Licença / License

Textos: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Código: MIT. Ver [`LICENSE`](LICENSE).

Contato / Contact: dasilveira.araujo@proton.me

Uma iniciativa de / An initiative by Luciano da Silveira Araújo.
